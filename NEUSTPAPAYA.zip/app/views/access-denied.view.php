<?= $this-> view('includes/dashboard-header');?>




<div class="main-panel">
    <div class="content-wrapper">
      <div class="row justify-content-center">
        <div class="col-lg-12 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
                <center class="alert-danger p-5">
                    <h1 class="text-dark">ACCESS DENIED!</h1>
                    <h4>You do not have the right privelage to access this content!</h4>
                </center>
            </div>
          </div>
        </div>
      </div>
<?= $this-> view('includes/dashboard-footer');?>