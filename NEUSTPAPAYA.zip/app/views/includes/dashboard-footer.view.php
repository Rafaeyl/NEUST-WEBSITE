<!-- partial:partials/_footer.html -->

<!-- partial -->
</div>
<!-- main-panel ends -->
</div>
<!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->
<!-- plugins:js -->
<script src="<?= ROOT ?>assets/dashboard/vendors/js/vendor.bundle.base.js"></script>
<!-- endinject -->
<!-- Plugin js for this page -->
<script src="<?= ROOT ?>assets/dashboard/vendors/chart.js/Chart.min.js"></script>
<script src="<?= ROOT ?>assets/dashboard/js/jquery3.js" type="text/javascript"></script>
<script src="<?= ROOT ?>assets/dashboard/js/datatable.min.js" type="text/javascript"></script>
<script src="<?= ROOT ?>assets/dashboard/js/bootstrap5.min.js" type="text/javascript"></script>
<script src="<?= ROOT ?>assets/dashboard/js/main.js" type="text/javascript"></script>
<!-- End plugin js for this page -->
<!-- inject:js -->
<script src="<?= ROOT ?>assets/dashboard/js/off-canvas.js"></script>
<script src="<?= ROOT ?>assets/dashboard/js/hoverable-collapse.js"></script>
<script src="<?= ROOT ?>assets/dashboard/js/misc.js"></script>
<!-- endinject -->
<!-- Custom js for this page -->
<script src="<?= ROOT ?>assets/dashboard/js/dashboard.js"></script>
<script src="<?= ROOT ?>assets/dashboard/js/todolist.js"></script>
<!-- End custom js for this page -->
</body>

</html>